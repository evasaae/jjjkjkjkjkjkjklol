/*
Nim  : D1041241012
Nama : Eva Safitri
Program penggunaan operator aritmatika dasar
 */

public class p022WorkingVariable {
    public static void main(String[] args) {
        //Deklarasi dan Inisialisasi variabel
        int angka = 10;
        //Menampilkan nilai awal variabel
        System.out.println("Nilai awal angka = " + angka);
        //Mengubah nilai variabel
        angka = 25;
        //Menamppilkan nilai setelah perubahan
        System.out.println("Nilai angka setelah diubah = " + angka);
    }
}