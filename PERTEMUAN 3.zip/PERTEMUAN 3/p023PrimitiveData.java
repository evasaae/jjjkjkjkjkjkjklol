/*
Nim  : D1041241012
Nama : Eva Safitri
Program penggunaan operator aritmatika dasar
 */

public class p023PrimitiveData {
    public static void main(String[] args) {
        //
        int umur = 20;
        long populasi = 8000000000L;
        //Tipe data bilangan desimal 
        float tinggi = 170.5f;
        double ipk = 3.75;
        //Tipe data karakter
        char nilaiHuruf = 'A';
        //logika
        boolean lulus = true;
        //Menampilkan nilai semua variabel
        System.out.println("Umur : " + umur);
        System.out.println("Populasi : " + populasi);
        System.out.println("Tinggi Badan : " + tinggi);
        System.out.println("IPK : " + ipk);
        System.out.println("Nilai Huruf : " + nilaiHuruf);
        System.out.println("Status lulus : " + lulus);
    }
}