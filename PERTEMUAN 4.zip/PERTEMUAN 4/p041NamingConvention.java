/*
Nim  : D1041241012
Nama : Eva Safitri
Program penerapan Naming Convention
 */

public class p041NamingConvention {
public static final double PI = 3.14;
public static void main(String[] args) {
// Deklarasi Variabel dengan camelCase
int studentAge = 20;
String studentName = "Budi";
boolean isActive = true;
// Menampilkan nilai semua variabel
System.out.println("Nama: " + studentName);
System.out.println("Umur: " + studentAge);
System.out.println("Status: " + isActive);
System.out.println("Konstanta PI: " + PI);
}
}