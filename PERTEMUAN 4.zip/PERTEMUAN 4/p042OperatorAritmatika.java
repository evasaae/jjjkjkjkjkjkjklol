/*
Nim  : D1041241012
Nama : Eva Safitri
Program penggunaan operator aritmatika dasar
 */

public class p042OperatorAritmatika {
public static void main(String[] args) {
    //deklarasi variabel
int a = 10;
int b = 3;
System.out.println("a = " + a);
System.out.println("b = " + b);
System.out.println();
System.out.println("a + b = " + (a + b));
System.out.println("a - b = " + (a - b));
System.out.println("a * b = " + (a * b));
System.out.println("a / b = " + (a / b));
System.out.println("a % b = " + (a % b));
// Pembagian dengan desimal
double hasil = (double) a / b;
System.out.println("a / b (desimal) = " + hasil);
}
}